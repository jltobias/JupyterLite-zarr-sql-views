const path = require('path');
const version = require('./package.json').version;

// Custom webpack rules
const rules = [
  { test: /\.ts$/, loader: 'ts-loader'  },
  { test: /\.js$/, loader: 'source-map-loader' },
  {
    test: /\.svg$/i,
    resourceQuery: /raw/,
    type: 'asset/source'
  },
  {
    test: /\.(gif|jpe?g|png|svg|mp4|glb|gltf)$/,
    resourceQuery: { not: [/raw/] },
    type: 'asset/resource'
  },
  {
    // numcodecs references zfp_codec.wasm via new URL(..., import.meta.url).
    // Keep the URL string at runtime instead of forcing webpack to resolve the file at build time.
    test: /numcodecs[\\/]zfp_codec-[^\\/]+\.js$/,
    parser: {
      javascript: {
        url: false
      }
    }
  },
  { test: /\.html$/, loader: 'raw-loader'},
  { test: /\.css$/, use: ['style-loader', 'css-loader']}
];

// Packages that shouldn't be bundled but loaded at runtime
const externals = ['@jupyter-widgets/base'];

const resolve = {
  // Add '.ts' and '.tsx' as resolvable extensions.
  extensions: [".webpack.js", ".web.js", ".ts", ".js"],
  alias: {
    // JupyterLab builder bundles from lib/, but binary assets live in src/.
    './pin.glb$': path.resolve(__dirname, 'src', 'lexcube-client', 'src', 'client', 'pin.glb'),
    // Compiled JS references a TS worker extension; remap to emitted JS worker.
    './geojson-loader.worker.ts$': path.resolve(__dirname, 'lib', 'lexcube-client', 'src', 'client', 'rendering', 'geojson-loader.worker.js'),
    // Optional codec binary not present in pinned numcodecs tarball.
    'zfp_codec.wasm$': false,
  }
};


module.exports = [
  /**
   * Notebook extension
   *
   * This bundle only contains the part of the JavaScript that is run on load of
   * the notebook.
   */
  {
    entry: './src/extension.ts',
    output: {
      filename: 'index.js',
      path: path.resolve(__dirname, 'lexcube', 'nbextension'),
      libraryTarget: 'amd',
      publicPath: '',
    },
    module: {
      rules: rules
    },
    devtool: 'source-map',
    externals,
    resolve,
  },

  /**
   * Embeddable lexcube bundle
   *
   * This bundle is almost identical to the notebook extension bundle. The only
   * difference is in the configuration of the webpack public path for the
   * static assets.
   *
   * The target bundle is always `dist/index.js`, which is the path required by
   * the custom widget embedder.
   */
  {
    entry: './src/index.ts',
    output: {
        filename: 'index.js',
        path: path.resolve(__dirname, 'dist'),
        libraryTarget: 'amd',
        library: "lexcube",
        publicPath: 'https://cdn.jsdelivr.net/npm/lexcube@' + version + '/dist/'
    },
    devtool: 'source-map',
    module: {
        rules: rules
    },
    externals,
    resolve,
  },


  /**
   * Documentation widget bundle
   *
   * This bundle is used to embed widgets in the package documentation.
   */
  {
    entry: './src/index.ts',
    output: {
      filename: 'embed-bundle.js',
      path: path.resolve(__dirname, 'docs', 'source', '_static'),
      library: "lexcube",
      libraryTarget: 'amd'
    },
    module: {
      rules: rules
    },
    devtool: 'source-map',
    externals,
    resolve,
  }

];
