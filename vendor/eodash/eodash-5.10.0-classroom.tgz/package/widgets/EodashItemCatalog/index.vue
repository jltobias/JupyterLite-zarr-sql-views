<template>
  <div class="d-flex flex-column">
    <v-row
      v-if="showTitleBlock"
      class="title align-center justify-space-between flex-shrink-0"
    >
      <h4>Catalog Items</h4>
      <div class="d-flex align-center">
        <v-menu v-if="sortByOptions?.length" v-model="sortMenu" offset-y>
          <template #activator="{ props: menuProps }">
            <v-tooltip location="bottom">
              <template #activator="{ props: tooltipProps }">
                <v-btn
                  v-bind="{ ...menuProps, ...tooltipProps }"
                  icon
                  size="small"
                  color="primary"
                  class="mr-2"
                  aria-label="Sort"
                  variant="text"
                >
                  <v-icon>mdi-sort</v-icon>
                </v-btn>
              </template>
              <span>Sort items</span>
            </v-tooltip>
          </template>
          <v-list density="compact" color="primary">
            <v-list-item
              v-for="option in sortByOptions"
              :key="option.property"
              :active="selectedSort?.property === option.property"
              @click="selectSort(option)"
            >
              <v-list-item-title>
                {{ option.label }}
                <v-icon
                  v-if="selectedSort?.property === option.property"
                  size="x-small"
                  class="ml-1"
                >
                  {{ sortOrder === "+" ? "mdi-arrow-up" : "mdi-arrow-down" }}
                </v-icon>
              </v-list-item-title>
            </v-list-item>
          </v-list>
        </v-menu>
        <EodashLayoutSwitcher
          v-if="layoutTarget && layoutIcon"
          :target="layoutTarget"
          :icon="layoutIcon"
        />
      </div>
    </v-row>
    <eox-itemfilter
      ref="itemfilter"
      class="itemfilter-scroll"
      .titleProperty="titleProperty"
      .imageProperty="imageProperty"
      .subTitleProperty="subTitleProperty"
      .filterProperties="filterProperties"
      .items="items"
      .styleOverride="itemfilterStyleOverride"
      :externalFilter="externalFilterHandler"
      @select="onSelectItem"
      @filter="onFilter"
      @mouseenter:result="onMouseEnterResult"
      @mouseleave:result="onMouseLeaveResult"
    >
      <h4 slot="filterstitle" style="margin: 14px 8px">{{ filtersTitle }}</h4>
      <h4 slot="resultstitle" style="margin: 14px 8px">{{ resultsTitle }}</h4>
    </eox-itemfilter>
  </div>
</template>

<script setup>
import {
  computed,
  nextTick,
  onUnmounted,
  ref,
  useTemplateRef,
  watch,
} from "vue";
import { storeToRefs } from "pinia";

import { useSTAcStore } from "@/store/stac";
import {
  createExternalFilter,
  createSubtitleProperty,
  resolveSearchFields,
} from "./methods/filters";
import { useCatalogConfig } from "./composables/useCatalogConfig";
import {
  useSearchOnMapMove,
  useRenderItemsFeatures,
  useHoverTooltip,
  useRenderOnFeatureClick,
  renderItemsFeatures,
} from "./methods/map";
import {
  createOnFilterHandler,
  createOnSelectHandler,
  createOnMouseEnterResult,
  createOnMouseLeaveResult,
} from "./methods/handlers";
import { mdiViewDashboard } from "@mdi/js";
import EodashLayoutSwitcher from "^/EodashLayoutSwitcher.vue";
import { indicator, mapCompareEl, mapEl, mapPosition } from "@/store/states";
import axios from "@/plugins/axios";
import { layerTimeProperties } from "@/utils/states";
import {
  useInitMosaic,
  renderLatestMosaic,
  useScheduleMosaicUpdate,
  useMosaicState,
} from "@/eodashSTAC/mosaic";

if (!customElements.get("eox-itemfilter")) {
  await import("@eox/itemfilter");
}

// Props definition
const props = defineProps({
  title: {
    type: String,
    default: "Explore Catalog",
  },
  titleProperty: {
    type: /** @type {import("vue").PropType<import("./types").ItemAccessor>} */ ([
      String,
      Function,
    ]),
    default: "id",
  },
  hoverProperties: {
    /** @type {import("vue").PropType<string[]>} */
    type: Array,
    default: () => ["datetime", "eo:cloud_cover"],
  },
  sortBy: {
    /** @type {import("vue").PropType<{ property: string, label: string }[]>} */
    type: Array,
    default: () => [
      { property: "datetime", label: "Date" },
      { property: "eo:cloud_cover", label: "Cloud Cover" },
    ],
  },
  layoutTarget: {
    type: String,
    default: "lite",
  },
  layoutIcon: {
    type: String,
    default: mdiViewDashboard,
  },
  filtersTitle: {
    type: String,
    default: "Filters:",
  },
  resultsTitle: {
    type: String,
    default: "Items:",
  },
  datetimeFilter: {
    type: Boolean,
    default: false,
  },
  bboxFilter: {
    type: Boolean,
    default: true,
  },
  subTitleProperty: {
    type: /** @type {import("vue").PropType<import("./types").ItemAccessor>} */ ([
      String,
      Function,
    ]),
    default: undefined,
  },
  imageProperty: {
    type: /** @type {import("vue").PropType<import("./types").ItemAccessor>} */ ([
      String,
      Function,
    ]),
    default: "assets.thumbnail.href",
  },
  showTitleBlock: {
    type: Boolean,
    default: true,
  },
  filters: {
    /** @type {import("vue").PropType<import("./types").FiltersConfig>} */
    type: Array,
    default: () => [
      {
        property: "eo:cloud_cover",
        type: "range",
        title: "Cloud Cover (%)",
        min: 0,
        max: 100,
        step: 1,
        state: {
          min: 0,
          max: 30,
        },
        icon: `<svg style="height: 1rem; transform: translateY(-2px); fill: currentColor" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><title>weather-cloudy</title><path d="M6,19A5,5 0 0,1 1,14A5,5 0 0,1 6,9C7,6.65 9.3,5 12,5C15.43,5 18.24,7.66 18.5,11.03L19,11A4,4 0 0,1 23,15A4,4 0 0,1 19,19H6M19,13H17V12A5,5 0 0,0 12,7C9.5,7 7.45,8.82 7.06,11.19C6.73,11.07 6.37,11 6,11A3,3 0 0,0 3,14A3,3 0 0,0 6,17H19A2,2 0 0,0 21,15A2,2 0 0,0 19,13Z" /></svg>`,
        unitLabel: "%",
      },
    ],
  },
  enableCompare: {
    type: Boolean,
    default: false,
  },
  /**
   * Show the declared filters and their `filterKeys` as-is, without fetching
   * per-collection metadata to resolve/narrow options. Use for large catalogs
   * where fetching every collection's summaries/queryables does not scale.
   */
  staticFilters: {
    type: Boolean,
    default: false,
  },
  useMosaic: {
    type: Boolean,
    default: false,
  },
  /**
   * Whether data layers carry the collection's dates for a global time control.
   * Off by default, since the catalog is the time navigation.
   */
  timeControlValues: {
    type: Boolean,
    default: false,
  },
  mosaicIndicators: {
    /** @type {import("vue").PropType<string[]>} */
    type: Array,
    required: false,
    default: undefined,
  },
  stacEndpoint: {
    type: String,
    default: null,
  },
  searchLimit: {
    type: Number,
    default: 100,
  },
  stacItemsStyle: {
    type: Object,
    required: false,
    default: undefined,
  },
  stacItemsInteractionStyle: {
    type: Object,
    required: false,
    default: undefined,
  },
});

const itemfilterEl = useTemplateRef("itemfilter");

const sortMenu = ref(false);
const sortOrder = ref("-");
/** @type {import("vue").Ref<{ property: string, label: string } | null>} */
const selectedSort = ref(null);
const sortByParam = ref("-datetime");
/** Rebuild sortByParam from the current property and order. */
function updateSortByParam() {
  sortByParam.value = `${sortOrder.value === "+" ? "" : "-"}${
    selectedSort.value?.property ?? "datetime"
  }`;
}
/**
 * Handle sort option selection
 * @param {{ property: string, label: string }} option
 */
function selectSort(option) {
  if (selectedSort.value?.property === option.property) {
    sortOrder.value = sortOrder.value === "-" ? "+" : "-";
  } else {
    selectedSort.value = option;
    sortOrder.value = "-";
  }
  updateSortByParam();
  sortMenu.value = false;
  if (itemfilterEl.value) {
    itemfilterEl.value.search();
  }
}

const store = useSTAcStore();
const { selectedItem, selectedCompareItem } = storeToRefs(store);

/** The map this catalog draws on. The prop cannot change after setup. */
const mapElement = props.enableCompare ? mapCompareEl : mapEl;

const catalogEndpoint = computed(
  () => props.stacEndpoint || store.stacEndpoint,
);
const {
  isItemView,
  latestLayer,
  visibilityThreshold,
  returnToOverview,
  mosaicEndpoint,
} = useMosaicState();

const isMosaicEnabled = computed(
  () => props.useMosaic && !!mosaicEndpoint.value,
);

const activeSelectedItem = props.enableCompare
  ? selectedCompareItem
  : selectedItem;

if (props.useMosaic) {
  const unsubscribeReturn = returnToOverview.on(() => {
    activeSelectedItem.value = null;
  });
  onUnmounted(() => {
    unsubscribeReturn();
    isItemView.value = false;
  });
}

// the catalog is the time navigation, so the layers keep only the selected item's own step
layerTimeProperties.layerDatetime = "currentStep";
layerTimeProperties.timeControlValues = props.timeControlValues;
onUnmounted(() => {
  activeSelectedItem.value = undefined;
  layerTimeProperties.layerDatetime = true;
  layerTimeProperties.timeControlValues = true;
});

/** @type {import("vue").Ref<import("@/types").GeoJsonFeature[]>} */
const currentItems = ref([]);

const items = currentItems.value;

const searchFields = catalogEndpoint.value
  ? await resolveSearchFields(catalogEndpoint.value, [
      props.titleProperty,
      props.subTitleProperty,
      props.imageProperty,
    ])
  : undefined;

if (catalogEndpoint.value) {
  await axios
    .get(catalogEndpoint.value + "/search", {
      params: { limit: props.searchLimit, fields: searchFields },
    })
    .then((res) => (currentItems.value = res.data.features));
}

const {
  filterProperties,
  sortByOptions,
  hoverProperties: effectiveHoverProperties,
  applyCollections,
} = useCatalogConfig({
  itemfilterEl,
  datetimeFilter: props.datetimeFilter,
  declaredFilters: props.filters ?? [],
  declaredSortBy: props.sortBy ?? [],
  declaredHoverProperties: props.hoverProperties ?? [],
  endpoint: /** @type {string} */ (catalogEndpoint.value),
  staticFilters: props.staticFilters,
});

/**
 * @param {string[]} ids selected collection ids
 * @returns {string[]} collection ids to resolve the config against
 */
const resolveCollectionIds = (ids) => {
  if (ids.length) {
    return ids;
  }
  return (store.stac ?? []).map((col) => /** @type {string} */ (col.id));
};

const initialCollections = indicator.value ? [indicator.value] : [];
await applyCollections(
  props.staticFilters ? [] : resolveCollectionIds(initialCollections),
);
selectedSort.value = sortByOptions.value[0] ?? null;
updateSortByParam();

const subTitleProperty = createSubtitleProperty(
  props.subTitleProperty,
  props.filters ?? [],
);

const externalFilterHandler = createExternalFilter(
  props.filters ?? [],
  props.bboxFilter,
  props.datetimeFilter,
  currentItems,
  sortByParam,
  props.searchLimit,
  activeSelectedItem,
  catalogEndpoint,
  searchFields,
);

watch(activeSelectedItem, (item) => {
  if (itemfilterEl.value) {
    itemfilterEl.value.selectedResult = item ?? null;
  }

  if (isMosaicEnabled.value) {
    isItemView.value = !!item;
  }

  // restore mosaic when item is deselected
  if (!isMosaicEnabled.value || item) return;
  if (latestLayer.value) {
    renderLatestMosaic();
    renderItemsFeatures(
      currentItems.value,
      mapElement,
      effectiveHoverProperties.value,
      props.stacItemsStyle,
      props.stacItemsInteractionStyle,
    );
    nextTick(() => {
      const z = mapPosition.value[2] ?? 0;
      const layer = mapEl.value?.getLayerById(
        /** @type {string} */ (latestLayer.value?.properties?.id),
      );
      layer?.setVisible(z >= visibilityThreshold.value);
    });
  }
});

// re-add items features after mosaic layer is rendered
watch(
  () => latestLayer.value,
  (layer) => {
    if (!isMosaicEnabled.value || !layer) return;
    renderItemsFeatures(
      currentItems.value,
      mapElement,
      effectiveHoverProperties.value,
      props.stacItemsStyle,
      props.stacItemsInteractionStyle,
    );
  },
);

const scheduleMosaicUpdate = useScheduleMosaicUpdate();

// Event handlers
const onFilter = createOnFilterHandler({
  currentItems,
  mapElement,
  hoverProperties: effectiveHoverProperties,
  stacItemsStyle: props.stacItemsStyle,
  stacItemsInteractionStyle: props.stacItemsInteractionStyle,
  itemfilterEl,
  selectedItemRef: activeSelectedItem,
  initialCollections,
  onCollectionsChange: async (collectionIds) => {
    if (props.staticFilters) return;
    await applyCollections(resolveCollectionIds(collectionIds));
    // keep the user's sort when the new collection still offers it
    const stillValid = sortByOptions.value.some(
      (option) => option.property === selectedSort.value?.property,
    );
    if (!stillValid) {
      selectedSort.value = sortByOptions.value[0] ?? null;
      sortOrder.value = "-";
      updateSortByParam();
      itemfilterEl.value?.search();
    }
  },
  mosaicOptions: isMosaicEnabled.value
    ? {
        isMosaicEnabled,
        getMosaicEndpoint: () => mosaicEndpoint.value,
        scheduleMosaicUpdate,
      }
    : null,
});

/**
 * @param {CustomEvent} evt
 */
const onSelectItem = createOnSelectHandler(
  store,
  props.enableCompare,
  mapElement,
  catalogEndpoint,
);

useRenderItemsFeatures(
  currentItems,
  mapElement,
  effectiveHoverProperties,
  props.stacItemsStyle,
  props.stacItemsInteractionStyle,
);
useSearchOnMapMove(itemfilterEl, props.bboxFilter, mapElement);
useRenderOnFeatureClick(itemfilterEl, mapElement, onSelectItem);
useInitMosaic(
  props.useMosaic ? mosaicEndpoint.value : null,
  undefined,
  props.mosaicIndicators,
);

useHoverTooltip(effectiveHoverProperties);
const onMouseEnterResult = createOnMouseEnterResult(mapElement);
const onMouseLeaveResult = createOnMouseLeaveResult(mapElement);

const itemfilterStyleOverride = `
  li.highlighted {
    background-color: rgb(var(--v-theme-primary)) !important;
    color: rgb(var(--v-theme-on-primary)) !important;
  }
  li.highlighted .subtitle {
    opacity: 0.85;
  }
  .title-container.truncate,
  .title.truncate,
  .subtitle.truncate {
    white-space: normal !important;
    overflow: visible !important;
    text-overflow: unset !important;
  }
  .title {
    display: block;
    line-height: 1.25;
    overflow-wrap: anywhere;
    word-break: break-word;
  }
  nav.responsive i.small {
    width: 72px !important;
    height: 72px !important;
    min-width: 72px;
    min-height: 72px;
    flex: 0 0 72px;
  }
  nav.responsive i.small .image {
    width: 100%;
    height: 100%;
    object-fit: cover;
    border-radius: 8px;
    padding:4px;
  }
`;
</script>
<style scoped>
.itemfilter-scroll {
  flex: 1;
  min-height: 0;
  overflow: hidden;
  padding: 0.5rem;
  --eox-itemfilter-results-color: var(--v-theme-primary) !important;
}

.title {
  padding: 1em;
  margin: 0.2em;
  flex-shrink: 0;
}
</style>
