import { sanitizeBbox } from "@eodash/stac/helpers";
import { indicator, mapEl } from "@/store/states";
import { useSTAcStore } from "@/store/stac";
import axios from "@/plugins/axios";
import { buildCqlFilter } from "@/eodashSTAC/cql";

/**
 * Creates a subtitle generator from filter configuration.
 *
 * @param {import("../types").ItemAccessor | undefined} subtitleProperty
 * @param {import("../types").FiltersConfig} filtersConfig
 */
export const createSubtitleProperty = (subtitleProperty, filtersConfig) => {
  if (subtitleProperty) {
    return subtitleProperty;
  }
  /**
   * @param {Record<string, any>} item
   */ // should be dynamic based on a prop
  return (item) => {
    let subtitle = "";
    filtersConfig.forEach((filter) => {
      const property = filter.property;
      if ((!filter.icon && !filter.unitLabel) || !item.properties[property]) {
        return;
      }
      if (filter.icon) {
        subtitle += filter.icon;
      }

      let value = item.properties[property];
      if (typeof value === "number" && !Number.isInteger(value)) {
        value = value.toFixed(1);
      }

      subtitle += value;

      if (filter.unitLabel) {
        subtitle += filter.unitLabel;
      }
    });
    return subtitle;
  };
};

/**
 * Transforms filter configs into eox-itemfilter property definitions.
 *
 * @param {Array<{
 *   property: string,
 *   type: "range" | "multiselect" | "select",
 *   title?: string,
 *   min?: number,
 *   max?: number,
 *   step?: number,
 *   filterKeys?: string[],
 *   state?: Record<string, boolean>,
 *   placeholder?: string,
 *   format?: string,
 * }>} filtersConfig
 * @param {boolean} datetimeFilter
 */
export const createFilterProperties = (filtersConfig, datetimeFilter) => {
  const store = useSTAcStore();
  const customDatetimeConfig = filtersConfig.find(
    (f) => f.property === "datetime",
  );
  const baseFilters = [
    {
      key: "collection",
      title: "Collections",
      type: "multiselect",
      placeholder: "Select collections",
      inline: false,
      filterKeys:
        store.stac?.filter((col) => col.id).map((col) => col.id) || [],
      ...(indicator.value && { state: { [indicator.value]: true } }),
    },
    ...(datetimeFilter || customDatetimeConfig
      ? [
          {
            key: "datetime",
            title: "Date",
            type: "range",
            format: "date",
            ...(customDatetimeConfig || {}),
          },
        ]
      : []),
  ];

  const dynamicFilters = filtersConfig
    .filter((f) => f.property !== "datetime")
    .map((filter) => {
      const propertyKey = `properties.${filter.property}`;

      if (filter.type === "range") {
        return {
          key: propertyKey,
          title: filter.title || filter.property,
          type: "range",
          expanded: true,
          min: filter.min,
          max: filter.max,
          step: filter.step,
          format: filter.format,
          filterKeys: [filter.min || 0, filter.max || 100],
          state: filter.state ?? {
            min: filter.min ?? 0,
            max: filter.max ?? 100,
          },
        };
      } else if (filter.type === "multiselect") {
        return {
          key: propertyKey,
          title: filter.title || filter.property,
          type: "multiselect",
          placeholder: filter.placeholder || `Select ${filter.property}`,
          inline: false,
          filterKeys: filter.filterKeys || [],
          state: filter.state,
        };
      } else if (filter.type === "select") {
        return {
          key: propertyKey,
          title: filter.title || filter.property,
          type: "select",
          placeholder:
            filter.placeholder || `Select ${filter.title || filter.property}`,
          filterKeys: filter.filterKeys || [],
          state: filter.state,
        };
      }

      return null;
    })
    .filter(Boolean);

  return [...baseFilters, ...dynamicFilters];
};

/**
 * The `fields` parameter trimming search results to what the catalog shows.
 * None without the fields extension or with a function accessor.
 *
 * @param {string} endpoint
 * @param {(import("../types").ItemAccessor | undefined)[]} accessors
 * @returns {Promise<string | undefined>}
 */
export const resolveSearchFields = async (endpoint, accessors) => {
  if (accessors.some((accessor) => typeof accessor === "function")) {
    return undefined;
  }
  /** @type {string[]} */
  const conformsTo = await axios
    .get(`${endpoint}/conformance`)
    .then((res) => res.data.conformsTo ?? [])
    .catch((error) => {
      console.warn("[eodash] Failed to read the API conformance", error);
      return [];
    });
  if (!conformsTo.some((uri) => uri.endsWith("item-search#fields"))) {
    return undefined;
  }
  const assetPaths = accessors.flatMap((accessor) =>
    typeof accessor === "string" && accessor.startsWith("assets.")
      ? [accessor]
      : [],
  );
  return [
    "type",
    "id",
    "bbox",
    "geometry",
    "collection",
    "properties",
    ...assetPaths,
    "-links",
  ].join(",");
};

/**
 * Builds a STAC API search URL from the given filter parameters.
 *
 * @param {import("@/types").ItemFilterFilters} filters
 * @param {boolean} bboxFilter
 * @param {boolean} datetimeFilter
 * @param {number} searchLimit
 * @param {string} [sortBy]
 * @param {string | null} [stacEndpoint]
 * @param {string} [fields] - {@link resolveSearchFields}
 * @returns {string}
 */
export const buildSearchUrl = (
  filters,
  bboxFilter,
  datetimeFilter,
  searchLimit,
  sortBy,
  stacEndpoint,
  fields,
) => {
  const store = useSTAcStore();
  const endpoint = stacEndpoint || store.stacEndpoint;
  const params = new URLSearchParams();

  if (filters.collection?.stringifiedState) {
    params.append(
      "collections",
      filters.collection.stringifiedState.replaceAll(" ", ""),
    );
  }

  if (mapEl.value?.lonLatExtent && bboxFilter) {
    params.append(
      "bbox",
      sanitizeBbox([...mapEl.value.lonLatExtent]).join(","),
    );
  }

  if (datetimeFilter) {
    const datetime = formatDatetimeParam(
      /** @type {import("@/types").ItemFilterRange} */ (filters.datetime),
    );
    if (datetime) {
      params.append("datetime", datetime);
    }
  }

  const cqlFilter = buildCqlFilter(filters);
  if (cqlFilter) {
    params.append("filter", cqlFilter);
  }
  if (sortBy) {
    params.append("sortby", sortBy);
  }

  params.append("limit", searchLimit.toString());
  if (fields) {
    params.append("fields", fields);
  }

  return `${endpoint}/search?${params.toString()}`;
};

/**
 * Creates an external filter fetcher for eox-itemfilter integration.
 *
 * @param {import("../types").FiltersConfig} propsFilters
 * @param {boolean} bboxFilter
 * @param {boolean} datetimeFilter
 * @param {import("vue").Ref<import("@/types").GeoJsonFeature[]>} currentItems
 * @param {import("vue").Ref<string>} sortBy
 * @param {number} searchLimit
 * @param {import("vue").Ref<import("@eodash/stac").STACItem | null | undefined>} [selectedItemRef]
 * @param {import("vue").Ref<string | null> | string | null} [stacEndpoint]
 * @param {string} [fields] - {@link resolveSearchFields}
 */
export const createExternalFilter = (
  propsFilters,
  bboxFilter,
  datetimeFilter,
  currentItems,
  sortBy,
  searchLimit,
  selectedItemRef,
  stacEndpoint,
  fields,
) => {
  const hasCustomDatetime = propsFilters.some((f) => f.property === "datetime");
  const effectiveDatetimeFilter = datetimeFilter || hasCustomDatetime;
  let controller = new AbortController();
  /**
   * @param {Array<any>} _items
   * @param {Record<string,any>} filters
   */
  return (_items, filters) => ({
    url: buildSearchUrl(
      filters,
      bboxFilter,
      effectiveDatetimeFilter,
      searchLimit,
      sortBy.value,
      typeof stacEndpoint === "object" ? stacEndpoint?.value : stacEndpoint,
      fields,
    ),
    /** @param {string} url */
    fetchFn: async (url) => {
      controller.abort();
      controller = new AbortController();
      const signal = controller.signal;
      return await axios
        .get(url, { signal })
        .then((res) => {
          /** @type {import("@/types").GeoJsonFeature[]} */
          const results = res.data.features;
          const selected = selectedItemRef?.value;
          if (selected && !results.some((r) => r.id === selected.id)) {
            return [selected, ...results];
          }
          return results;
        })
        .catch((e) => {
          // return previous items if aborted
          if (e.name === "AbortError" || e.name === "CanceledError") {
            return currentItems.value;
          }
          console.error(e);
          return [];
        });
    },
  });
};
/**
 * Formats datetime range bounds into an RFC 3339 interval string for STAC API queries.
 *
 * @param {import("@/types").ItemFilterRange} datetimeFilter
 */
function formatDatetimeParam(datetimeFilter) {
  if (!datetimeFilter) {
    return null;
  }
  const min = datetimeFilter?.min ? new Date(datetimeFilter.min) : null;
  const max = datetimeFilter?.max ? new Date(datetimeFilter.max) : null;
  const start = datetimeFilter.state?.min
    ? new Date(datetimeFilter.state.min)
    : null;
  const end = datetimeFilter.state?.max
    ? new Date(datetimeFilter.state.max)
    : null;
  const includeStart = start && (!min || start > min);
  const includeEnd = end && (!max || end < max);
  if (!includeStart && !includeEnd) {
    return null;
  }
  return `${includeStart ? start.toISOString() : ".."}/${includeEnd ? end.toISOString() : ".."}`;
}
