import { useOnLayersUpdate } from "@/composables";
import { onMounted, onUnmounted, watch } from "vue";
import { tooltipAdapter } from "@/store/states";
import { CATALOG_GROUP, assignGroupLayers } from "@/eodashSTAC/layers";

/**
 *
 * @param {import("@/types").GeoJsonFeature[]} features
 * @param {import("vue").Ref<import("@eox/map").EOxMap | null>} mapElement
 * @param {string[] | undefined} hoverProperties
 * @param {object} [stacItemsStyle]
 * @param {object} [stacItemsInteractionStyle]
 */
export function renderItemsFeatures(
  features,
  mapElement,
  hoverProperties,
  stacItemsStyle,
  stacItemsInteractionStyle,
) {
  const currentMap = mapElement.value;
  if (!currentMap || !features) {
    return;
  }
  // its own group, so a data rebuild cannot evict it
  const catalogGroup =
    /** @type {import("@eox/map/src/layers").EOxLayerTypeGroup | undefined} */ (
      currentMap.layers?.find((l) => l.properties?.id === CATALOG_GROUP)
    );
  /** @type {import("@eox/map").EoxLayer} */
  const stacItemsLayer = /** @type {any} */ ({
    type: "Vector",
    properties: {
      id: "stac-items",
      title: "STAC Items",
    },
    source: {
      type: "Vector",
      url:
        "data:application/geo+json," +
        encodeURIComponent(
          JSON.stringify({
            type: "FeatureCollection",
            // id for click/highlight, properties for tooltips and styles; assets and links are not needed
            features: features.map(({ id, geometry, properties }) => ({
              type: "Feature",
              id,
              geometry,
              properties,
            })),
          }),
        ),
      format: "GeoJSON",
      projection: "EPSG:4326",
    },
    style: stacItemsStyle || {
      "fill-color": "transparent",
      "stroke-color": "#003170",
    },
    interactions: [
      {
        type: "select",
        options: {
          id: "stac-item-hover",
          condition: "pointermove",
          active: true,
          tooltip: hoverProperties?.length,
          style: stacItemsInteractionStyle || {
            "stroke-color": "white",
            "stroke-width": 3,
          },
        },
      },
      {
        type: "select",
        options: {
          id: "stac-items",
          condition: "click",
          active: true,
          tooltip: false,
          style: stacItemsInteractionStyle || {
            "stroke-color": "#003047",
            "stroke-width": 3.2,
          },
        },
      },
    ],
  });
  const exists = catalogGroup?.layers.some(
    (/** @type {import("@eox/map").EoxLayer} */ l) =>
      l.properties?.id === stacItemsLayer.properties?.id,
  );
  if (exists) {
    currentMap.addOrUpdateLayer(stacItemsLayer);
    return;
  }
  // should be fixed in eox-map upstream
  for (const id of ["stac-items", "stac-item-hover"]) {
    if (currentMap.selectInteractions?.[id]) currentMap.removeSelect(id);
  }
  assignGroupLayers(currentMap, CATALOG_GROUP, [stacItemsLayer]);
}

/**
 * @param {import("vue").Ref<any>} itemFilter
 * @param {boolean} bboxFilter
 * @param {import("vue").Ref<import("@eox/map").EOxMap | null>} mapElement
 */
export const useSearchOnMapMove = (itemFilter, bboxFilter, mapElement) => {
  if (!bboxFilter) {
    return;
  }
  /** @type {NodeJS.Timeout} */
  let timeout;
  const handler = () => {
    clearTimeout(timeout);
    timeout = setTimeout(() => {
      if (mapElement.value?.projection == "globe") {
        return;
      }
      itemFilter.value?.search();
    }, 500);
  };

  watch(
    mapElement,
    (map, _, onCleanup) => {
      map?.map.on("moveend", handler);
      onCleanup(() => map?.map.un("moveend", handler));
    },
    { immediate: true },
  );
};
/**
 *
 * @param {import("vue").Ref<import("@/types").GeoJsonFeature[]>} currentItems
 * @param {import("vue").Ref<import("@eox/map").EOxMap | null>} mapElement
 * @param {import("vue").Ref<string[] | undefined>} hoverProperties
 * @param {object} [stacItemsStyle]
 * @param {object} [stacItemsInteractionStyle]
 */
export const useRenderItemsFeatures = (
  currentItems,
  mapElement,
  hoverProperties,
  stacItemsStyle,
  stacItemsInteractionStyle,
) => {
  onMounted(() => {
    renderItemsFeatures(
      currentItems.value,
      mapElement,
      hoverProperties.value,
      stacItemsStyle,
      stacItemsInteractionStyle,
    );
  });

  useOnLayersUpdate(() => {
    // consider cases where this is not needed
    renderItemsFeatures(
      currentItems.value,
      mapElement,
      hoverProperties.value,
      stacItemsStyle,
      stacItemsInteractionStyle,
    );
  });
};
/**
 * Registers a tooltip adapter that displays item properties when hovering over map features.
 * @param {import("vue").Ref<string[] | undefined>} hoverProperties
 */
export function useHoverTooltip(hoverProperties) {
  /**
   * @param {*} val
   */
  const formatValue = (val) => {
    if (typeof val === "number") {
      return val.toFixed(0);
    }

    if (typeof val === "string") {
      // Attempt to parse as date if string looks like ISO date
      if (val.length > 9 && /\d{4}-\d{2}-\d{2}/.test(val)) {
        const timestamp = Date.parse(val);
        if (!isNaN(timestamp)) {
          return new Date(timestamp).toUTCString();
        }
      }
    }
    return val;
  };
  /**
   * @param {string} key
   */
  const formatKey = (key) => {
    let formattedKey = key;
    if (key.includes(":")) {
      formattedKey = key.split(":")[1];
    }
    return formattedKey
      .replace(/_/g, " ")
      .replace(/\b\w/g, (c) => c.toUpperCase());
  };
  onMounted(() => {
    tooltipAdapter.value = ({ key, value }) => {
      if (value != null && hoverProperties.value?.includes(key)) {
        return { key: formatKey(key), value: formatValue(value) };
      }
      return undefined;
    };
  });
  onUnmounted(() => {
    tooltipAdapter.value = null;
  });
}

/**
 * Selects the item a clicked footprint belongs to, through the same handler the
 * result list uses — so a map click and a list click cannot diverge.
 *
 * @param {import("vue").Ref<any>} itemfilterEl
 * @param {import("vue").Ref<import("@eox/map").EOxMap | null>} mapElement
 * @param {(evt: CustomEvent) => unknown} onSelectItem
 */
export function useRenderOnFeatureClick(
  itemfilterEl,
  mapElement,
  onSelectItem,
) {
  /**
   *
   * @param {CustomEvent} evt
   */
  const handler = (evt) => {
    if (evt.detail.originalEvent.type !== "click") {
      return;
    }
    const itemId = evt.detail?.feature?.getId();
    if (!itemId) {
      return;
    }
    const item = itemfilterEl.value.results?.find(
      //@ts-expect-error todo
      (r) => r?.id === itemId,
    );

    if (item) {
      onSelectItem(new CustomEvent("select", { detail: item }));
    }
  };

  watch(
    mapElement,
    (map, _, onCleanup) => {
      //@ts-expect-error todo
      map?.addEventListener("select", handler);
      //@ts-expect-error todo
      onCleanup(() => map?.removeEventListener("select", handler));
    },
    { immediate: true },
  );
}
