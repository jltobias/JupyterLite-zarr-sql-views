import { initProcess, updateJsonformIdentifier } from "./handling";
import { useDebounceFn } from "@vueuse/core";
import { nextTick, onMounted, onUnmounted, watch } from "vue";
import { useOnLayersUpdate } from "@/composables";
import { getCompareLayers, getLayers } from "@/store/actions";
/**
 * Composable resposible of timing the Initialization of the process
 *
 * @async
 * @param {object} params
 * @param {import("vue").Ref<import("@eodash/stac").STACCollection | null>} params.selectedStac
 * @param {import("vue").Ref<Record<string,any> | null>} params.jsonformSchema
 * @param {import("vue").Ref<any[]>} params.processResults
 * @param {import("vue").Ref<boolean>} params.isProcessed
 * @param {import("vue").Ref<boolean>} params.loading
 * @param {import("vue").Ref<boolean>} params.isPolling
 * @param {import("vue").Ref<import("@eox/map").EOxMap | null>} params.mapElement
 */
export const useInitProcess = ({
  selectedStac,
  jsonformSchema,
  isProcessed,
  processResults,
  loading,
  isPolling,
  mapElement,
}) => {
  onMounted(async () => {
    await initProcess({
      enableCompare: mapElement.value?.id === "compare",
      selectedStac,
      jsonformSchema,
      isProcessed,
      processResults,
      loading,
      isPolling,
      mapElement: mapElement.value,
    });
  });

  useOnLayersUpdate(async (evt) => {
    const enableCompare = mapElement.value?.id === "compare";
    const layerUpdatedKey = enableCompare
      ? "compareLayers:updated"
      : "layers:updated";
    const timeUpdatedKeys = enableCompare
      ? ["compareLayertime:updated", "compareTime:updated"]
      : ["layertime:updated", "time:updated"];

    if (timeUpdatedKeys.includes(evt)) {
      // we need to update jsonform on time change in cases
      // when the feature selection layer was time-based,
      // so that it attaches to a correct new layer
      const newJsonForm = await updateJsonformIdentifier({
        jsonformSchema: jsonformSchema.value,
        newLayers: enableCompare ? getCompareLayers() : getLayers(),
        enableCompare,
        mapElement: mapElement.value,
      });

      if (newJsonForm) {
        // Layer rebuilds strip drawtools' selection interactions; remount
        // the form so initSelection re-attaches them.
        const selectionStripped =
          Object.values(newJsonForm.properties ?? {}).some(
            (p) => p?.options?.drawtools?.layerId,
          ) &&
          !mapElement.value?.selectInteractions?.[
            "SelectLayerClickInteraction"
          ];
        if (selectionStripped) {
          jsonformSchema.value = null;
          await nextTick();
        }
        jsonformSchema.value = newJsonForm;
      }
    }

    if (evt !== layerUpdatedKey) {
      return;
    }
    await initProcess({
      enableCompare,
      selectedStac,
      jsonformSchema,
      isProcessed,
      processResults,
      loading,
      isPolling,
      mapElement: mapElement.value,
    });
  });
};

/**
 * Auto execute the process when the jsonform has the execute option
 *
 * @param {import("vue").Ref<boolean>} autoExec
 * @param {import("vue").Ref<import("@eox/jsonform").EOxJSONForm | null>} jsonformEl
 * @param {import("vue").Ref<Record<string,any> | null>} jsonformSchema
 * @param {() => Promise<void>} startProcess
 **/
export function useAutoExec(
  autoExec,
  jsonformEl,
  jsonformSchema,
  startProcess,
) {
  const onJsonFormChange = useDebounceFn(() => startProcess(), 200);

  watch(jsonformSchema, (updatedSchema) => {
    autoExec.value = updatedSchema?.options?.["execute"] || false;
  });

  // Re-attach listener whenever the element or autoExec changes
  const stop = watch(
    [autoExec, jsonformEl],
    async ([exec, el], [_prevExec, prevEl]) => {
      // Cleanup if previous element existed
      if (prevEl) {
        prevEl.removeEventListener("change", onJsonFormChange);
      }
      // Add if enabled and we have an element
      if (exec && el) {
        // remove listener before adding to avoid duplicates in case of element change
        el.removeEventListener("change", onJsonFormChange);
        await nextTick();
        el.addEventListener("change", onJsonFormChange);
      }
    },
    { immediate: true },
  );

  onUnmounted(() => {
    if (jsonformEl.value) {
      jsonformEl.value.removeEventListener("change", onJsonFormChange);
    }
    stop();
  });
}
