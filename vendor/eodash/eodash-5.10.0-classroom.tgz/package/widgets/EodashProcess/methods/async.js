import { compareIndicator, indicator } from "@/store/states";
// we don't want to use the caching axios instance here
import axios from "axios";
import {
  applyProcessLayersToMap,
  creatAsyncProcessLayerDefinitions,
  download,
  extractAsyncResults,
} from "./utils";
import log from "loglevel";

/**
 * Polls the process status and fetches a result item when the process is successful.
 *
 * @param {object} params - Parameters for polling the process status.
 * @param {import("vue").Ref<import("../types").AsyncJob[]>} params.jobs - The list of jobs to update.
 * @param {string} params.processUrl - The URL of the process JSON report.
 * @param {import("vue").Ref<boolean>} params.isPolling - Checks whether polling should continue.
 * @param {number} [params.pollInterval=10000] - Interval (in ms) between polling attempts.
 * @param {number} [params.maxRetries=560] - Maximum number of polling attempts.
 * @param {boolean} [params.enableCompare=false] - Whether to enable comparison mode, affecting the indicator used.
 * @returns {Promise<import("../types").EOxHubProcessResults>} The fetched results JSON.
 * @throws {Error} If the process does not complete successfully within maxRetries.
 */
export async function pollProcessStatus({
  jobs,
  processUrl,
  isPolling,
  pollInterval = 10000,
  maxRetries = 560,
  enableCompare = false,
}) {
  let retries = 0;
  isPolling.value = true;
  // Ensure the jobs status is updated after the job has started and before polling
  setTimeout(() => {
    updateJobsStatus(
      jobs,
      enableCompare ? compareIndicator.value : indicator.value,
    );
  }, 500);

  while (retries < maxRetries && isPolling.value) {
    // Fetch the process JSON report
    const cacheBuster = new Date().getTime(); // Add a timestamp for cache busting
    const processReport = await axios
      .get(`${processUrl}?t=${cacheBuster}`)
      .then((resp) => resp.data)
      .catch((error) => {
        console.error("Error while polling process status:", error);
        return null;
      });

    if (processReport?.status === "failed") {
      isPolling.value = false;
      throw new Error("Process failed.", { cause: processReport });
    }

    // Check if the status is "successful"
    if (processReport?.status === "successful") {
      console.log("Process completed successfully. Fetching result item...");

      // Extract the result item URL
      const resultsUrl = processReport.links[1]?.href;
      if (!resultsUrl) {
        throw new Error(`Result links not found in the process report.`);
      }

      // Fetch the result item
      return await axios.get(resultsUrl).then((resp) => resp.data);
    }

    if (processReport) {
      // Log the current status if not successful
      console.log(
        `Status: ${processReport.status}. Retrying in ${pollInterval / 1000} seconds...`,
      );
    }

    // Wait for the next poll
    await new Promise((resolve) => setTimeout(resolve, pollInterval));
    retries++;
  }
  if (!isPolling.value) {
    console.warn("Polling was stopped before the process was completed.");
    return JSON.parse("{}");
  }

  throw new Error(
    "Max retries reached. Process did not complete successfully.",
  );
}

/**
 *
 * @param {import("vue").Ref<import("../types").AsyncJob[]>} jobs
 * @param {string} indicator
 */
export async function updateJobsStatus(jobs, indicator) {
  /** @type {string[]} */
  const jobsUrls = JSON.parse(localStorage.getItem(indicator) || "[]");
  /** @type {import("../types").AsyncJob[]} */
  const jobResults = await Promise.all(
    jobsUrls
      .filter((url) => typeof url === "string")
      .map((url) =>
        axios
          .get(url, { params: { t: Date.now() } })
          .then((response) => response.data)
          .catch((error) => {
            if (axios.isAxiosError(error)) {
              console.warn(
                `Job URL not accessible: ${url}. Maybe was deleted from the processing endpoint or endpoint is unavailable. Skipping...`,
              );
              return null;
            }
            throw error;
          }),
      ),
  );
  const validResults = jobResults
    .filter((job) => job !== null)
    .sort((a, b) => {
      return (
        new Date(b.job_start_datetime).getTime() -
        new Date(a.job_start_datetime).getTime()
      );
    });
  jobs.value.splice(0, jobs.value.length, ...validResults);
}

/**
 * Removes a job from the local storage and updates the job status
 * @param {import("vue").Ref<import("../types").AsyncJob[]>} jobs
 * @param {import("../types").AsyncJob} jobObject
 * @param {string} indicator
 */
export const deleteJob = async (jobs, jobObject, indicator) => {
  /** @type {string[]} */
  const jobsUrls = JSON.parse(localStorage.getItem(indicator) || "[]");
  const newJobs = jobsUrls.filter(
    (url) => typeof url === "string" && !url.includes(jobObject.jobID),
  );
  localStorage.setItem(indicator, JSON.stringify(newJobs));
  await updateJobsStatus(jobs, indicator);
};

/**
 * Downloads an existing process results
 * @param {import("../types").AsyncJob} jobObject
 * @param {import("@eodash/stac").STACCollection | null} selectedStac
 */
export const downloadPreviousResults = async (jobObject, selectedStac) => {
  /** @type {string[]} */
  const results = [];
  const link = jobObject.links.find(
    (link) => link.rel.includes("results") && link.type == "application/json",
  );
  if (!link) {
    return;
  }
  await axios
    .get(link.href)
    .then((response) => response.data)
    .then((data) => {
      // either urls is an Array
      if (data.urls) {
        results.push(...data.urls);
      } else {
        // or urls need to be aggregated from mapping objects
        for (const outputMappingObject of Object.values(data)) {
          results.push(...outputMappingObject.urls);
        }
      }
    });
  results.forEach((result) => {
    if (!result) {
      return;
    }
    let fileName = "";
    if (typeof result === "string") {
      fileName = result.includes("/")
        ? (result.split("/").pop() ?? "")
        : result;
      fileName = fileName.includes("?") ? fileName.split("?")[0] : fileName;
    } else {
      fileName = selectedStac?.id + "_process_results.json";
    }
    download(fileName, result);
  });
};

/**
 * Load the process results and update the map layers.
 *
 * @async
 * @param {import("../types").AsyncJob} jobObject
 * @param {import("@eodash/stac").STACCollection | null} selectedStac
 * @param {import("@eox/map").EOxMap | null} mapElement
 */
export const loadProcess = async (jobObject, selectedStac, mapElement) => {
  /** @type {import("../types").EOxHubProcessResults} */
  const results = await axios
    .get(jobObject.links[1].href)
    .then((response) => response.data);

  await loadPreviousProcess({
    selectedStac,
    results,
    jobId: jobObject.jobID,
    mapElement,
  });
};

/**
 * load a geotiff to the map from an existing process
 *
 * @param {object} params
 * @param {import("@eodash/stac").STACCollection | null} params.selectedStac
 * @param {string} params.jobId
 * @param {import("../types").EOxHubProcessResults} params.results
 * @param {import("@eox/map").EOxMap | null} params.mapElement
 */
export async function loadPreviousProcess({
  selectedStac,
  results,
  jobId,
  mapElement,
}) {
  const asyncLink = selectedStac?.links.find(
    (link) => link.rel === "service" && link.endpoint == "eoxhub_workspaces",
  );
  if (!asyncLink) {
    return;
  }

  const unifiedResult = extractAsyncResults(results);

  const layers = await creatAsyncProcessLayerDefinitions(
    unifiedResult,
    asyncLink,
    selectedStac,
    jobId,
  );

  log.debug("rendered layers after loading previous process:", layers);
  applyProcessLayersToMap(mapElement, layers);
}

/**
 * extracts job status url from local storage based on identifier
 *
 * @param {string} jobID
 * @param {string} indicator
 */
export const getJobStatusUrl = (jobID, indicator) => {
  /** @type {string[]} */
  const jobsUrls = JSON.parse(localStorage.getItem(indicator) || "[]");
  const jobUrl = jobsUrls.find(
    (url) => typeof url === "string" && url.includes(jobID),
  );
  return jobUrl;
};
