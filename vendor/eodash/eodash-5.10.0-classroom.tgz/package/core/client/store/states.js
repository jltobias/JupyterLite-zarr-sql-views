/** setting default log level globally to warning */
import log from "loglevel";
log.setLevel(log.levels.WARN, true);

import { reactive, ref, shallowRef } from "vue";

/** Currently selected STAC endpoint */
export const currentUrl = ref("");

/** Currently selected compare STAC endpoint */
export const currentCompareUrl = ref("");

/** Currently selected datetime */
export const datetime = ref("");

/** Currently selected indicator */
export const indicator = ref("");
/** Currently selected compare indicator */
export const compareIndicator = ref("");

/**
 * Current map position
 *
 * @type {import("vue").Ref<(number | undefined)[]>}
 */
export const mapPosition = ref([]);

export const registeredProjections = ["EPSG:4326", "EPSG:3857"];

/** available projection to be rendered by `EodashMap` */
export const availableMapProjection = ref("EPSG:3857");

/** @type {import("vue").Ref<import("@eox/map").EOxMap & { mapUpdateId?: number } | null>} */
export const mapEl = shallowRef(null);

/** @type {import("vue").Ref<import("@eox/map").EOxMap | null>} */
export const mapCompareEl = shallowRef(null);

export const activeTemplate = ref("");
/**
 * Selected point of interest, used for location collections
 */
export const poi = ref("");
/**
 * Selected point of interest for comparison, used for location collections
 */
export const comparePoi = ref("");

/** Whether the map is in globe mode */
export const isGlobe = ref(false);

/** Whether the charts are in fullscreen mode
 * @type {import("vue").Ref<boolean>}
 */
export const areChartsSeparateLayout = ref(false);

/** Holds main chart data
 *  @type {import("vue").Ref<Record<string,any>|null>}
 */
export const chartData = ref(null);

/** Holds compare chart data
 *  @type {import("vue").Ref<Record<string,any>|null>}
 */
export const compareChartData = ref(null);

/** Holds main chart spec
 * @type {import("vue").Ref<import("vega-embed").VisualizationSpec | null>}
 */
export const chartSpec = ref(null);

/** Holds compare chart spec
 * @type {import("vue").Ref<import("vega-embed").VisualizationSpec | null>}
 */
export const compareChartSpec = ref(null);

/** Global error state
 * @type {import("vue").Ref<{message: string, details: string, severity: "error" | "warning" | "info"}>}
 */
export const errorState = ref({ message: "", details: "", severity: "error" });

/**
 * Global loading state.
 * - `loading.activeLoads` — increment/decrement to track concurrent loads
 * - `loading.value` — derived boolean, true when `activeLoads > 0`
 */
export const loading = reactive({
  activeLoads: 0,
  get value() {
    return this.activeLoads > 0;
  },
});

/**
 * Adapter allows external widgets to hook into tooltip property transformation
 * @type {import("vue").Ref<((param: {key: string, value: any}, map?: string) => {key: string, value: any} | undefined) | null>}
 */
export const tooltipAdapter = shallowRef(null);
