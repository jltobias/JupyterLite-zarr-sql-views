import { mdiViewDashboard } from "@mdi/js";
import { includesProcess, shouldShowChartWidget } from "@/store/actions";

/** @type {import("@/types").Template} */
export default {
  loading: {
    id: "loading",
    type: "web-component",
    widget: {
      // https://uiball.com/ldrs/
      link: "https://cdn.jsdelivr.net/npm/ldrs/dist/auto/mirage.js",
      tagName: "l-mirage",
      properties: {
        class: "align-self-center justify-self-center",
        size: "120",
        speed: "2.5",
        color: "#004170",
      },
    },
  },
  background: {
    id: "background-map",
    type: "internal",
    widget: {
      name: "EodashMap",
      properties: {
        baseLayers: [
          /** @type {any} */ ({
            type: "Tile",
            properties: {
              id: "terrain-light;:;EPSG:3857",
              title: "Terrain Light",
              roles: ["baselayer", "visible"],
              group: "baselayer",
              visible: true,
              layerControlExclusive: true,
            },
            source: {
              type: "XYZ",
              url: "https://{a-e}.s2maps-tiles.eu/wmts/1.0.0/terrain-light_3857/default/g/{z}/{y}/{x}.jpeg",
              projection: "EPSG:3857",
              attributions:
                '{ OSM: Data &copy; <a href="http://www.openstreetmap.org/copyright" target="_blank">OpenStreetMap</a> contributors and <a href="https://maps.eox.at/#data" target="_blank">others</a>, Rendering &copy; <a href="http://eox.at" target="_blank">EOX</a> }',
            },
            preload: Infinity,
          }),
        ],
        enableCompare: true,
        zoomToExtent: true,
        btns: {
          enableZoom: true,
          enableExportMap: true,
          enableChangeProjection: true,
          enableCompareIndicators: {
            fallbackTemplate: "expert",
          },
          enableBackToPOIs: true,
          enableSearch: true,
          enableGlobe: true,
          // searchParams: {
          //   countrycode: "gb,ie,fr"
          //   bounds: "-84.26514,41.58998,-77.54150,46.14246"
          // },
        },
        btnsPosition: {
          x: "12/9/10",
          y: 1,
          gap: 16,
        },
      },
    },
  },
  widgets: [
    {
      id: "Tools",
      type: "internal",
      title: "Tools",
      layout: { x: 0, y: 0, w: "3/3/2", h: 2 },
      widget: {
        name: "EodashTools",
        properties: {
          layoutTarget: "lite",
          layoutIcon: mdiViewDashboard,
          itemFilterConfig: {
            resultType: "cards",
            subTitleProperty: "subtitle",
            imageProperty: "thumbnail",
            aggregateResults: "collection_group",
          },
        },
      },
    },
    {
      id: "Layercontrol",
      type: "internal",
      title: "Layers",
      layout: { x: 0, y: 1, w: "3/3/2", h: 10 },
      widget: {
        name: "EodashLayerControl",
        properties: {
          cssVars: {
            "--list-padding": "1rem",
          },
        },
      },
    },
    {
      defineWidget: (selectedSTAC) => {
        return selectedSTAC
          ? {
              id: "Information",
              title: "Information",
              layout: { x: "9/9/10", y: 0, w: "3/3/2", h: 6 },
              type: "internal",
              widget: {
                name: "EodashStacInfo",
              },
            }
          : null;
      },
    },
    {
      defineWidget: (selectedSTAC) => {
        return selectedSTAC
          ? {
              id: "expert-datepicker",
              type: "internal",
              layout: { x: 3, y: 3, w: 5, h: 9 },
              title: "Date",
              widget: {
                name: "EodashDatePicker",
                properties: {
                  toggleCalendar: true,
                },
              },
            }
          : null;
      },
    },
    {
      defineWidget: (selectedSTAC) =>
        includesProcess(selectedSTAC) && {
          id: "Processes",
          type: "internal",
          title: "Processes",
          layout: { x: "9/9/10", y: 6, w: "3/3/2", h: 6 },
          widget: {
            name: "EodashProcess",
          },
        },
    },
    {
      defineWidget: () =>
        shouldShowChartWidget() && {
          id: "ProcessResultChart",
          type: "internal",
          title: "Chart",
          layout: { x: 0, y: 0, w: 12, h: 8 },
          widget: {
            name: "EodashChart",
          },
        },
    },
  ],
};
